import { Component } from '@angular/core';
import { FormControl, FormGroup, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HeaderComponent } from '../../layout/header/header.component';

@Component({
  selector: 'app-login',
  imports: [ReactiveFormsModule, HeaderComponent],
  standalone: true,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {

  modelForm: FormGroup;
getDataForm() {
throw new Error('Method not implemented.');
}
titulo: string;

constructor() {
this.titulo = 'Web del reto';
this.modelForm = new FormGroup({
  name: new FormControl(null, []),
  password: new FormControl (null, [])

  }, [])
}

}
